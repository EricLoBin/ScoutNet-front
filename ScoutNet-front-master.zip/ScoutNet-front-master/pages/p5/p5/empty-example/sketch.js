function setup() {
    creteCanvas(200, 200);
}
function draw() {
    circle(20, 30, 80, 80);
}